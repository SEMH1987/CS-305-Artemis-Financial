package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class ChecksumController {
	// endpoint we'll use in the browser SHA-256 hash of a string
    @GetMapping("/hash")
    public String getMyChecksum() {
    	// data to hash
        String data = "Steves secret cryptography";
        try {
        	// creates a SHA-256 MessageDigest instance
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));

             // convert the string into bytes and compute the hash
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);  // mask to get unsigned value
                if (hex.length() == 1) hexString.append('0'); // pad single-digit hex
                hexString.append(hex);
            }

            // return the original string and its SHA-256 hash
            return "Original data:\n" + data + "\nSHA-256 Hash:\n" + hexString.toString();

        } catch (NoSuchAlgorithmException e) {
        	// Handles when SHA-256 is not supported
            return "Error computing the hash: " + e.getMessage();
        }
    }
}